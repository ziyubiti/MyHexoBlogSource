---
title: NB-IoT
date: 2016-07-26 16:26:28
tags: [NB-IoT,LTE]
categories: 5G
---



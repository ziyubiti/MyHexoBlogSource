---
title: 开源推荐系统Crab安装
date: 2016-07-01 16:24:22
tags: [Crab,Python]
categories: Python
---

安装环境：Ubuntu kylin 16.04 LTS， 自带 python 2.7.11


1. 依赖numpy，scikit.learn、scipy、matplotlib， 使用pip安装；

2. 在 https://github.com/muricoca/crab 下载crab源码包，用python setup.py install 安装；

3. 使用自带movie或song数据集，测试可用。


crab的使用，可参考官方文档：http://muricoca.github.io/crab/tutorial.html#introducing-recommendation-engines

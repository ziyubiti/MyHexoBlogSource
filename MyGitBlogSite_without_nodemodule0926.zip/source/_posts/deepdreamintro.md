---
title: Deep Dream 初体验 - 神经网络模型眼中的世界
date: 2016-09-08 20:11:03
tags: DeepLearning
categories: ML
---

　　2015年年中Google发布了Deep Dream的新闻，展示了google神经网络模型对输入图片的理解，类似于“深度盗梦”，并引发了后续的艺术风格作画。  
　　Deep Dream，其原理并不是尽可能地去正确识别图片对象，而是在网络识别对象模式的中间过程时，忽略确认操作，这样就解除了最小梯度限制，Test loss不再越来越小；而是让网络在已识别出的错误对象上，继续去强化认知和理解，最终找出了新图像的模板，而这迥异于原图的风格，形成了类似于创造梦境的效果。  
　　Google的示例如下：  
　　![google deep dream example 1](../../../../imgs/deepdream/googledeepdream.jpg)  
　　![google deep dream example 2 - 原图](../../../../imgs/deepdream/googledeepdream2.jpg)  
　　![google deep dream example 2 - 转换图](../../../../imgs/deepdream/googledeepdream3.jpg)  
　　![google deep dream example 3 - 原图](../../../../imgs/deepdream/googledeepdream4.jpg)  
　　![google deep dream example 3 - 转换图](../../../../imgs/deepdream/googledeepdream5.jpg)  　　

　　再来自己试试效果，代码参考[keras examples](https://github.com/fchollet/keras/blob/master/examples/deep_dream.py),基于Keras、Tensorflow和VGG16模型。  
　　对上面的太空飞碟图进行操作，效果图如下：  
　　![VGG deep dream](../../../../imgs/deepdream/vgg.png)  
　　
　　可以看出，Google的效果图大部分都是各种动物，尤其是狗居多；而VGG的模型则相对平淡，主要是色彩和线条轮廓。这主要是由于Google Deep Dream使用的神经网络模型采用了ImageNet1000的数据集进行训练得到的，这个数据集与真实世界相比采样偏差较大，里面大部分都是动物，上百类狗、几十类鸟等，这样模型很容易将随机噪声识别出动物轮廓线条，从而强化这一印象而创造出来。反之，VGG训练使用的数据集则相对比较广泛，效果图也就没有明显突出特征。
　　由此思考，对于通用智能而言，比如拟人态机器人，如何准确识别世界上的大部分物体呢？物品种类海量，用一个超大的神经网络模型进行运算？还是针对不同种类物品，分别训练出很多个小型神经网络模型，并行处理更好？
　　




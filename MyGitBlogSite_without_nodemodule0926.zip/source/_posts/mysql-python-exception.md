---
title: MySQL Connection not available的定位
date: 2016-08-16 20:04:33
tags: Python
categories: Python
---

　　Python在读写远程MySql数据库时，在数据量略大时（约4000条），总是运行一段时间后，过程中出现：OperationalError: MySQL Connection not available，查看代码与cursor = conn.cursor()有关。  
　　网上查了些资料，与MySql的固有bug有关（http://bugs.mysql.com/bug.php?id=67649）：  
```
Description:
If you open an unbuffered cursor and you do not read the WHOLE result set before closing the cursor, the next query will fail with

  File "/usr/lib/python3.2/site-packages/mysql/connector/connection.py", line 1075, in cursor
    raise errors.OperationalError("MySQL Connection not available.")
mysql.connector.errors.OperationalError: MySQL Connection not available.

and all subsequent database calls will fail too.
```
　　即：若打开了一个cursor，但没有把所有结果集都fetch一遍就close，那么后面这个conn就丢了。  
　　临时解决方案如下，添加注释掉部分：  
``` python
sql = "SELECT a FROM foo"
cursor = dbh.cursor()
cursor.execute( sql )
dbRec = cursor.fetchone()
#while cursor.fetchone():       # comment this out to fix the "bug"
#    pass
cursor.close()
print( dbRec )
```
　　按此方法测试，读写远程数据库仍然出错。另外即使不打这个补丁，读写本地数据库却不报错。  
　　本地数据库为5.6版本，已将wait_timeout修改为500；而远程数据库为5.1版本，配置文件未知，估计应该是默认值wait_timeout=50.这样看来，可能与wait_timeout参数有关。  

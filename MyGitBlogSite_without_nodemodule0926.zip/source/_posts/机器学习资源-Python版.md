---
title: 机器学习资源-Python版
date: 2016-07-13 16:37:49
tags: [MachineLearning,Python]
categories: [ML]
---


内容摘自：https://github.com/jobbole/awesome-machine-learning-cn


**计算机视觉**

- SimpleCV—开源的计算机视觉框架，可以访问如OpenCV等高性能计算机视觉库。使用Python编写，可以在Mac、Windows以及Ubuntu上运行。

**自然语言处理**

- NLTK —一个领先的平台，用来编写处理人类语言数据的Python程序
- Pattern—Python可用的web挖掘模块，包括自然语言处理、机器学习等工具。
- TextBlob—为普通自然语言处理任务提供一致的API，以NLTK和Pattern为基础，并和两者都能很好兼容。
- jieba—中文断词工具。
- SnowNLP —中文文本处理库。
- loso—另一个中文断词库。
- genius —基于条件随机域的中文断词库。
- nut —自然语言理解工具包。

**通用机器学习**

- Bayesian Methods for Hackers —Python语言概率规划的电子书
- MLlib in Apache Spark—Spark下的分布式机器学习库。
- scikit-learn—基于SciPy的机器学习模块
- graphlab-create —包含多种机器学习模块的库（回归，聚类，推荐系统，图分析等），基于可以磁盘存储的DataFrame。
- BigML—连接外部服务器的库。
- pattern—Python的web挖掘模块
- NuPIC—Numenta公司的智能计算平台。
- Pylearn2—基于Theano的机器学习库。
- hebel —Python编写的使用GPU加速的深度学习库。
- gensim—主题建模工具。
- PyBrain—另一个机器学习库。
- Crab —可扩展的、快速推荐引擎。
- python-recsys —Python实现的推荐系统。
- thinking bayes—关于贝叶斯分析的书籍
- Restricted Boltzmann Machines —Python实现的受限波尔兹曼机。[深度学习]。
- Bolt —在线学习工具箱。
- CoverTree —cover tree的Python实现，scipy.spatial.kdtree便捷的替代。
- nilearn—Python实现的神经影像学机器学习库。
- Shogun—机器学习工具箱。
- Pyevolve —遗传算法框架。
- Caffe —考虑了代码清洁、可读性及速度的深度学习框架
- breze—深度及递归神经网络的程序库，基于Theano。

**数据分析/数据可视化**

- SciPy —基于Python的数学、科学、工程开源软件生态系统。
- NumPy—Python科学计算基础包。
- Numba —Python的低级虚拟机JIT编译器，Cython and  NumPy的开发者编写，供科学计算使用
- NetworkX —为复杂网络使用的高效软件。
- Pandas—这个库提供了高性能、易用的数据结构及数据分析工具。
- Open Mining—Python中的商业智能工具（Pandas web接口）。
- PyMC —MCMC采样工具包。
- zipline—Python的算法交易库。
- PyDy—全名Python Dynamics，协助基于NumPy, SciPy, IPython以及 matplotlib的动态建模工作流。
- SymPy —符号数学Python库。
- statsmodels—Python的统计建模及计量经济学库。
- astropy —Python天文学程序库，社区协作编写
- matplotlib —Python的2D绘图库。
- bokeh—Python的交互式Web绘图库。
- plotly —Python and matplotlib的协作web绘图库。
- vincent—将Python数据结构转换为Vega可视化语法。
- d3py—Python的绘图库，基于D3.js。
- ggplot —和R语言里的ggplot2提供同样的API。
- Kartograph.py—Python中渲染SVG图的库，效果漂亮。
- pygal—Python下的SVG图表生成器。
- pycascading

**杂项脚本/iPython笔记/代码库**

- pattern_classification
- thinking stats 2
- hyperopt
- numpic
- 2012-paper-diginorm
- python-notebooks
- decision-weights
- Sarah Palin LDA —Sarah Palin关于主题建模的电邮。
- Diffusion Segmentation —基于扩散方法的图像分割算法集合。
- Scipy Tutorials —SciPy教程，已过时，请查看scipy-lecture-notes
- Crab—Python的推荐引擎库。
- BayesPy—Python中的贝叶斯推断工具。
- scikit-learn tutorials—scikit-learn学习笔记系列
- sentiment-analyzer —推特情绪分析器
- group-lasso—坐标下降算法实验，应用于（稀疏）群套索模型。
- mne-python-notebooks—使用 mne-python进行EEG/MEG数据处理的IPython笔记
- pandas cookbook—使用Python pandas库的方法书。
- climin—机器学习的优化程序库，用Python实现了梯度下降、LBFGS、rmsprop、adadelta 等算法。

**Kaggle竞赛源代码**

- wiki challange —Kaggle上一个维基预测挑战赛 Dell Zhang解法的实现。
- kaggle insults—Kaggle上”从社交媒体评论中检测辱骂“竞赛提交的代码
- kaggle_acquire-valued-shoppers-challenge—Kaggle预测回头客挑战赛的代码
- kaggle-cifar —Kaggle上CIFAR-10 竞赛的代码，使用cuda-convnet
- kaggle-blackbox —Kaggle上blackbox赛代码，关于深度学习。
- kaggle-accelerometer —Kaggle上加速度计数据识别用户竞赛的代码
- kaggle-advertised-salaries —Kaggle上用广告预测工资竞赛的代码
- kaggle amazon —Kaggle上给定员工角色预测其访问需求竞赛的代码
- kaggle-bestbuy_big—Kaggle上根据bestbuy用户查询预测点击商品竞赛的代码（大数据版）
- kaggle-bestbuy_small—Kaggle上根据bestbuy用户查询预测点击商品竞赛的代码（小数据版）
- Kaggle Dogs vs. Cats —Kaggle上从图片中识别猫和狗竞赛的代码
- Kaggle Galaxy Challenge —Kaggle上遥远星系形态分类竞赛的优胜代码
- Kaggle Gender —Kaggle竞赛：从笔迹区分性别
- Kaggle Merck—Kaggle上预测药物分子活性竞赛的代码（默克制药赞助）
- Kaggle Stackoverflow—Kaggle上 预测Stack Overflow网站问题是否会被关闭竞赛的代码
- wine-quality —预测红酒质量。

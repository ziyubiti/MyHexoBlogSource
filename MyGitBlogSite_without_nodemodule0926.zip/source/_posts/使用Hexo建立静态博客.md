---
title: 使用Hexo建立静态博客
date: 2016-07-13 16:10:36
tags: Hexo
categories: Web
---

**环境配置**  
   
Hexo依赖于git与node.js环境：
1.安装git：
``` bash
sudo apt-get install git-core
```
2.安装node.js，首先安装nvm：
``` bash
curl https://raw.github.com/creationix/nvm/master/install.sh | sh，
```
然后重启控制台以安装Node.js，执行 
``` bash
nvm install stable
```
3.安装Hexo，执行
``` bash
npm install -g hexo-cli
```
4.执行：
``` bash
hexo init <folder>
cd <folder>
npm install
```
5.至此服务端环境配置完毕，folder下出现如下结构：
```
.  
├── _config.yml  
├── package.json  
├── scaffolds  
├── source  
|    ├── _drafts  
|    └── _posts  
└── themes  
```


**常用操作**  
在服务端目录folder下，在控制台执行：
 * 写文章：hexo new "title"  
 - 生成： hexo g ，文章位于source/_posts目录下 
 - 在本地查看：启动服务器 hexo server，查看 http://localhost:4000/  
 - 部署到远程：hexo d


 其它修改 网站名称、语言、菜单、视图之类，主要修改根目录下的_config.yml文件和对应主题下的_config.yml文件。  


**本地文件插入**
观察hexo的文件结构，本地更新的文章和图片都会上传到根目录public文件夹下，分别以 /年/月/日/文章名 这样的结构保存，而图片则保存在public文件夹下的 /imgs文件夹中。那么在写本地路径的时候，相对路径应该退回到该imgs文件夹下才可以成功链接到图片：
```
![图片说明](../../../../imgs/xx.jpg)
```




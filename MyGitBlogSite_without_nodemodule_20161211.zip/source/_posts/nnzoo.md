---
title: 神经网络架构大盘点--读Fjodor Van Veen的《neural-network-zoo》
date: 2016-12-11 14:33:58
tags: DeepLearning
categories: ML
---

　　各种神经网络架构层出不穷，比如DCIGN, BiLSTM, DCGAN等，Fjodor Van Veen总结了近几年来流行的神经网络各架构，易于直观理解。  
　　原文地址为：http://www.asimovinstitute.org/neural-network-zoo/  
　　总结如下：  
　　![neural network architectures](../../../../imgs/nnzoo/neuralnetworks.png)  

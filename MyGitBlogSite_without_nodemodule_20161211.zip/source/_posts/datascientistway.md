---
title: 数据科学家路线图 
date: 2016-10-11 16:55:42
tags: MachineLearning
categories: ML
---

网上搜到的，感谢原作者。
　　![](../../../../imgs/datascientistway/1.jpg)  


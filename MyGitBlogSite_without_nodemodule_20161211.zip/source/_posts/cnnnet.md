---
title: CNN经典网络模型摘要--AlexNet、ZFnet、GoogleNet、VGG、ResNet
date: 2016-11-27 17:23:58
tags: DeepLearning
categories: ML
---


　　CNN的经典结构始于1998年的LeNet，成于2012年历史性的AlexNet，从此大盛于图像相关领域，主要包括：  
　　1、LeNet，1998年  
　　2、AlexNet，2012年  
　　3、ZF-net，2013年  
　　4、GoogleNet，2014年  
　　5、VGG，2014年  
　　6、ResNet，2015年  

LeNet前面博文已介绍，下面再补充介绍下其它几种网络结构。  

AlexNet
-------
![AlexNet说明](../../../../imgs/cnnnet/Alex.png)  

ZF-Net
-------
![ZF-Net说明](../../../../imgs/cnnnet/ZF.png)  

GoogleNet
-------
![GoogleNet结构](../../../../imgs/cnnnet/google.png)  
![GoogleNet参数](../../../../imgs/cnnnet/google2.png)  
![GoogleNet说明](../../../../imgs/cnnnet/google3.png)  

VGG-Net  
-------
![VGG-Net结构](../../../../imgs/cnnnet/VGG.png)  

ResNet  
-------
![ResNet34层网络示例](../../../../imgs/cnnnet/resNet.png)  
![ResNet残差结构](../../../../imgs/cnnnet/resNet2.png)  
![ResNet参数](../../../../imgs/cnnnet/resNet3.png)  

总结  
-------
![CNN网络性能演进](../../../../imgs/cnnnet/comp.png)  
　　2016年ILSVRC的Top5-error已降到3%以下，不过主要采用的ensemble方法，相比前几年，出现较大革新方法的脚步有所放缓了。  

---
title: 如何改进深度学习的性能？
date: 2016-09-30 17:38:50
tags: DeepLearning
categories: ML
---

摘自：[How To Improve Deep Learning Performance](http://machinelearningmastery.com/improve-deep-learning-performance/)  

[1] Improve Performance With Data.
Get More Data.
Invent More Data.
Rescale Your Data.
Transform Your Data.
Feature Selection.　　

[2] Improve Performance With Algorithms.
Spot-Check Algorithms.
Steal From Literature.
Resampling Methods.　

[3] Improve Performance With Algorithm Tuning.
Diagnostics.
Weight Initialization.
Learning Rate.
Activation Functions.
Network Topology.
Batches and Epochs.
Regularization.
Optimization and Loss.
Early Stopping.　　

[4] Improve Performance With Ensembles.
Combine Models.
Combine Views.
Stacking.



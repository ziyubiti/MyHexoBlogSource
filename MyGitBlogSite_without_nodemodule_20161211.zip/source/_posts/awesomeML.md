---
title: 机器学习相关的Awesome系列
date: 2016-08-30 11:57:27
tags: MachineLearning
categories: ML
---
<p>原文链接：<a href="https://www.52ml.net/17812.html" target="_blank" rel="nofollow">[原创]机器学习相关的Awesome系列</a></p>
<div>
    <table>    
            <tr>
                <th>
                    Index
                </th>
                <th>
                    Awesome
                </th>
                <th>
                    备注
                </th>
            </tr>   
            <tr>
                <td>
                    1
                </td>
                <td>
                    <a href="https://github.com/josephmisiti/awesome-machine-learning" target="_blank" rel="nofollow">Awesome Machine Learning</a>
                </td>
                <td>
                    <a href="https://github.com/jobbole/awesome-machine-learning-cn" target="_blank" rel="nofollow">机器学习资源大全中文版</a>
                </td>
            </tr>
            <tr>
                <td>
                    2
                </td>
                <td>
                    <a href="https://github.com/owainlewis/awesome-artificial-intelligence" target="_blank" rel="nofollow">Awesome Artificial Intelligence</a>
                </td>
                <td>
                    人工智能
                </td>
            </tr>
            <tr>
                <td>
                    3
                </td>
                <td>
                    <a href="https://github.com/bayandin/awesome-awesomeness" target="_blank" rel="nofollow">Awesome Awesomeness</a><br>
                    <a href="https://github.com/sindresorhus/awesome" target="_blank" rel="nofollow">Awesome</a>
                </td>
                <td>
                    Awesome的平方，<br>
                    还有个立方但是不经典
                </td>
            </tr>
            <tr>
                <td>
                    4
                </td>
                <td>
                    <a href="https://github.com/ChristosChristofidis/awesome-deep-learning" target="_blank" rel="nofollow">Awesome Deep Learning</a>
                </td>
                <td>
                    深度学习
                </td>
            </tr>
            <tr>
                <td>
                    5
                </td>
                <td>
                    <a href="https://github.com/daviddao/awesome-very-deep-learning" target="_blank" rel="nofollow">Awesome Very Deep Learning</a>
                </td>
                <td>
                    非常深的深度学习
                </td>
            </tr>
            <tr>
                <td>
                    6
                </td>
                <td>
                    <a href="https://github.com/kristjankorjus/applied-deep-learning-resources" target="_blank" rel="nofollow">Applied Deep Learning Resources</a>
                </td>
                <td>
                    深度学习应用相关资源
                </td>
            </tr>
            <tr>
                <td>
                    7
                </td>
                <td>
                    <a href="http://www.deeplearningpatterns.com/doku.php/applications" target="_blank" rel="nofollow">Deep Learning Applications</a>
                </td>
                <td>
                    深度学习相关应用
                </td>
            </tr>
            <tr>
                <td>
                    8
                </td>
                <td>
                    <a href="https://github.com/kjw0612/awesome-deep-vision" target="_blank" rel="nofollow">Awesome Deep Vision</a>
                </td>
                <td>
                    深度视觉
                </td>
            </tr>
            <tr>
                <td>
                    9
                </td>
                <td>
                    <a href="http://meta-guide.com/software-meta-guide/100-best-github-deep-learning" target="_blank" rel="nofollow">100 Best GitHub: Deep Learning</a>
                </td>
                <td>
                    深度学习百佳GitHub，不只是代码
                </td>
            </tr>
            <tr>
                <td>
                    10
                </td>
                <td>
                    <a href="https://github.com/aymericdamien/TopDeepLearning" target="_blank" rel="nofollow">Top Deep Learning Projects</a>
                </td>
                <td>
                    按照GitHub星数排名的DL项目
                </td>
            </tr>
            <tr>
                <td>
                    11
                </td>
                <td>
                    <a href="https://github.com/terryum/awesome-deep-learning-papers" target="_blank" rel="nofollow">Awesome - Most Cited Deep Learning Papers</a>
                </td>
                <td>
                    引用最多的深度学习文章
                </td>
            </tr>
            <tr>
                <td>
                    12
                </td>
                <td>
                    <a href="http://meta-guide.com/videography/100-best-deep-learning-videos" target="_blank" rel="nofollow">100 Best Deep Learning Videos</a>
                </td>
                <td>
                    深度学习百佳视频
                </td>
            </tr>
            <tr>
                <td>
                    13
                </td>
                <td>
                    <a href="https://github.com/ujjwalkarn/Machine-Learning-Tutorials" target="_blank" rel="nofollow">Machine Learning &amp; Deep Learning Tutorials</a>
                </td>
                <td>
                    百佳机器学习深度学习指南
                </td>
            </tr>
            <tr>
                <td>
                    14
                </td>
                <td>
                    <a href="https://github.com/kjw0612/awesome-rnn" target="_blank" rel="nofollow">Awesome RNN</a>
                </td>
                <td>
                    RNN
                </td>
            </tr>
            <tr>
                <td>
                    15
                </td>
                <td>
                    <a href="https://github.com/carpedm20/awesome-torch" target="_blank" rel="nofollow">Awesome Torch</a>
                </td>
                <td>
                    Torch
                </td>
            </tr>
            <tr>
                <td>
                    16
                </td>
                <td>
                    <a href="https://github.com/jtoy/awesome-tensorflow" target="_blank" rel="nofollow">Awesome TensorFlow</a>
                </td>
                <td>
                    TensorFlow
                </td>
            </tr>
            <tr>
                <td>
                    17
                </td>
                <td>
                    <a href="https://github.com/TensorFlowKR/awesome_tensorflow_implementations" target="_blank" rel="nofollow">Awesome Tensorflow Implementations</a>
                </td>
                <td>
                    Tensorflow实现
                </td>
            </tr>
            <tr>
                <td>
                    18
                </td>
                <td>
                    <a href="https://github.com/andrewt3000/DL4NLP/blob/master/README.md" target="_blank" rel="nofollow">Deep Learning for NLP resources</a>
                </td>
                <td>
                    深度学习自然语言处理相关资源
                </td>
            </tr>
            <tr>
                <td>
                    19
                </td>
                <td>
                    <a href="https://github.com/keonkim/awesome-nlp" target="_blank" rel="nofollow">Awesome NLP</a>
                </td>
                <td>
                    自然语言处理
                </td>
            </tr>
            <tr>
                <td>
                    20
                </td>
                <td>
                    <a href="https://github.com/edobashira/speech-language-processing" target="_blank" rel="nofollow">Speech and Natural Language Processing</a>
                </td>
                <td>
                    语音和自然语言处理
                </td>
            </tr>
            <tr>
                <td>
                    21
                </td>
                <td>
                    <a href="https://github.com/MaxwellRebo/awesome-2vec" target="_blank" rel="nofollow">Awesome 2Vec</a>
                </td>
                <td>
                    深度学习 2Vec 系列
                </td>
            </tr>
            <tr>
                <td>
                    22
                </td>
                <td>
                    <a href="https://github.com/jbhuang0604/awesome-computer-vision" target="_blank" rel="nofollow">Awesome Computer Vision</a>
                </td>
                <td>
                    计算机视觉
                </td>
            </tr>
            <tr>
                <td>
                    23
                </td>
                <td>
                    <a href="https://github.com/onurakpolat/awesome-bigdata" target="_blank" rel="nofollow">Awesome Big Data</a>
                </td>
                <td>
                    大数据
                </td>
            </tr>
            <tr>
                <td>
                    24
                </td>
                <td>
                    <a href="https://github.com/okulbilisim/awesome-datascience" target="_blank" rel="nofollow">Awesome Data Science</a>
                </td>
                <td>
                    数据科学
                </td>
            </tr>
            <tr>
                <td>
                    25
                </td>
                <td>
                    <a href="https://github.com/kjw0612/awesome-random-forest" target="_blank" rel="nofollow">Awesome Random Forest</a>
                </td>
                <td>
                    随机森林
                </td>
            </tr>
            <tr>
                <td>
                    26
                </td>
                <td>
                    <a href="https://github.com/caesar0301/awesome-public-datasets" target="_blank" rel="nofollow">Awesome Public Datasets</a>
                </td>
                <td>
                    公开数据集
                </td>
            </tr>
            <tr>
                <td>
                    27
                </td>
                <td>
                    <a href="http://aikorea.org/awesome-rl/" target="_blank" rel="nofollow">Awesome Reinforcement Learning</a>
                </td>
                <td>
                    强化学习
                </td>
            </tr>
    </table> 
</div>   
  
  







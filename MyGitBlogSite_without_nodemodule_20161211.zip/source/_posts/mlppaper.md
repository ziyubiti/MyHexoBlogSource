---
title: 回归初心-读《Deep Big Simple Neural Nets Excel on Hand-written Digit Recognition》
date: 2016-10-18 19:20:19
tags: DeepLearning
categories: ML
---

　　Mnist做为手写数字识别的基准数据集，one Hidden Layer Perceptron已可以取得较好性能（Error rate 2%-5%），更有诸多新型网络结构如CNN、RNN不断改善性能（Error rate 1%以下）。
　　而这篇论文，则进一步回归初心，挖掘纯粹MLP的性能，通过可变学习速率，旋转、畸变数据以扩展训练集，更多隐藏层等，观察性能如下：
　　![MLP performance](../../../../imgs/MLP/MLP.png)  
　　
　　没有花拳绣腿，纯粹的MLP，同样可以得到错误率0.5%以下的性能，唯一的缺点就是计算量，方法上简单、粗暴、有效！

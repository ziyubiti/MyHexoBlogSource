---
title: LeNet简介
date: 2016-10-8 18:33:30
tags: DeepLearning
categories: ML
---


　　LeNet做为CNN的经典网络结构，如下。  
　　![LeNet-5架构](../../../../imgs/lenet/lenet1.png)  
　　![S2到C3的映射](../../../../imgs/lenet/lenet2.png)  
　　![LeNet-5参数量](../../../../imgs/lenet/lenet_para.png)  

　　对C3参数计算中，是1516还是1560的问题，CSDN网友[treasuresss](http://blog.csdn.net/treasuresss)回复说明如下：其实两者都正确！因为16=6+9+1，而60=6\*3+9\*4+1\*6，就拿6\*3来说，c3中的一张feature map卷了s2中的三张feature map，那么自然就有三个偏置项，但实际上三个偏置项的效果和把这三个偏置项整合成一个偏置项的效果是一样的，所以，c3中的前6张feature map涉及的偏置项可以说有6个也可以说有6\*3=18个，中间9张feature map涉及的偏置项可以说有9个也可以说有9\*4=36个，最后一张feature map涉及的偏置项可以说有1个也可以说有1\*6=6个。看看杨乐村的98论文，现在已经是1516了（据说有人以前看到好像是1560）。


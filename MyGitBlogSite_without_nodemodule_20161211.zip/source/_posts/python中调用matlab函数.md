---
title: python中调用matlab函数
date: 2015-12-11 17:00:17
tags: Python
categories: Python
---

python中调用matlab函数，主要使用mlab库，一个python-matlab接口。  

``` python
import mlab
from mlab.releases import latest_release as matlab
from numpy import *
[u,s,v] = matlab.svd(array([[1,2], [1,3]]), nout=3)
```

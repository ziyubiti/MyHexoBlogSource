---
title: 链家大数据使用到的机器学习算法
date: 2016-09-22 21:28:39
tags:  MachineLearning
categories: ML
---


摘自: [InfoQ对链家网大数据架构师蔡白银的访谈](http://mp.weixin.qq.com/s?__biz=MjM5MDE0Mjc4MA==&mid=2650994254&idx=2&sn=f591ab2d1a15a500fc1f12b6d55c52e9&chksm=bdbf0e1d8ac8870be98a3f0eff315f2e9d74b079601eec23ed472f54cabc1310a13e7885a5b0&scene=0#wechat_redirect)  

InfoQ：房地产数据挖掘会用到哪些算法？  
蔡白银：房产领域的数据挖掘用到的算法和平常大家用到的算法并不会有什么类别的不同，只是数据挖掘本身需要和业务紧密关联，所以这些算法在房产领域的使用细节上会有不同。  
    我们现如今已经使用的算法包括了 GBDT、随机森林、Hedonic、神经网络、卷积神经网络、逻辑回归、SVM、HMM、ItemCF、UserCF、聚类算法等。  
  GBDT、随机森林、Hedonic、神经网络是我们在估价中使用的。卷积神经网络是我们在户型图识别中使用的， 逻辑回归、SVM则是在用户画像中判别同一用户、和判别用户是否是买家还是卖家使用。HMM是我们用来描述用户买卖行为阶段的算法。 聚类则是用在相似的楼盘识别，也用在了房源推荐和小区推荐当中。  

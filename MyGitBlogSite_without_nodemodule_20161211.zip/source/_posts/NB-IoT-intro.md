---
title: NB-IoT简介(1)--下行公共信道与信号之NRS、NPSS、NSSS、NPBCH
date: 2016-07-26 16:26:28
tags: [NB-IoT]
categories: 5G
---

![](../../../../imgs/nbiot/basic.png)

NRS
---
　　![](../../../../imgs/nbiot/NRS.png)

NPSS
---
　　![](../../../../imgs/nbiot/NPSS.png)
　　
NSSS
---
　　![](../../../../imgs/nbiot/NSSS.png)

NPBCH
---
　　![](../../../../imgs/nbiot/NPBCH.png)



---
title: 为什么GoogleNet中的Inception Module使用1*1 convolutions?
date: 2016-11-13 16:06:08
tags: DeepLearning
categories: ML
---

　　GoogleNet的创新之处，在于引入了Inception Module，其采用了并行结构，如下：
　　![GoogleNet Inception Module](../../../../imgs/googlenet/inception.png)  
　　
　　其中1*1 conv的作用：  
　　简单说，是特征降维，是feature pooling，filter space的transform。这种跨特征层的级联结构，可以有助于不同特征层间的空间信息交互。论文中语:"This cascaded cross channel parameteric pooling structure allows complex and learnable interactions of cross channel information"。  
　　这篇文章的解释：http://iamaaditya.github.io/2016/03/one-by-one-convolution/  
　　youtube上的1x1 Convolutions/inception相关视频，如下：  
　　<video width="640" height="360" src="../../../../imgs/googlenet/1x1 Convolutions.mp4" autoplay="" loop="" controls="controls"></video>
　　<video width="640" height="360" src="../../../../imgs/googlenet/Inception Module.mp4" autoplay="" loop="" controls="controls"></video>

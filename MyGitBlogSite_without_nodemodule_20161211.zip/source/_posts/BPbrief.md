---
title: BP算法摘要与代码分析
date: 2016-09-18 21:52:37
tags: DeepLearning
categories: ML
---



　　反向传播算法是神经网络中的重要组成部分，是对权重和偏置变化影响代价函数过程的理解，目标是计算代价函数C 分别关于w 和b的偏导数，从而更新w、b，影响前向过程，最小化代价函数。  
　　![神经网络结构示意图](../../../../imgs/BP/0.png)  
　　![BP算法的4个方程](../../../../imgs/BP/1.png)  
　　公式BP1与BP2在nielsen的书[Neural Networks and Deep Learning](http://neuralnetworksanddeeplearning.com/chap2.html)中已有证明，下面补充BP3与BP4的证明：  
　　![BP3 and BP4 Proof](../../../../imgs/BP/2.png)  
　　BP算法过程如下：
　　![BP算法过程](../../../../imgs/BP/3.png)  
　　在m大小的mini_batch内进行一次梯度更新，过程如下：  
　　![mini_batch内的一次梯度更新](../../../../imgs/BP/4.png)    　　
　　
　　以mnist识别，三层网络[784,30,10]为例，nielsen的书中代码如下，添加了部分注释：  
``` python
class Network(object):
    def update_mini_batch(self, mini_batch, eta):

        """Update the network's weights and biases by applying

        gradient descent using backpropagation to a single mini batch.

        The ``mini_batch`` is a list of tuples ``(x, y)``, and ``eta``

        is the learning rate."""

        nabla_b = [np.zeros(b.shape) for b in self.biases]    # idx0:30*1; idx1:10*1

        nabla_w = [np.zeros(w.shape) for w in self.weights]   # idx0:30*784; idx1:10*30

        for x, y in mini_batch:                              # loop 10, BP calc  and update gradient 10 times

            delta_nabla_b, delta_nabla_w = self.backprop(x, y)        # delta b,delta w , their dimension is same as b,w

            nabla_b = [nb+dnb for nb, dnb in zip(nabla_b, delta_nabla_b)]  # bj:zip two column vector, but list output row by row

            nabla_w = [nw+dnw for nw, dnw in zip(nabla_w, delta_nabla_w)]

        self.weights = [w-(eta/len(mini_batch))*nw

                        for w, nw in zip(self.weights, nabla_w)]     # update w, sum the average 10 changes

        self.biases = [b-(eta/len(mini_batch))*nb

                       for b, nb in zip(self.biases, nabla_b)]       # update b,



    def backprop(self, x, y):

        """Return a tuple ``(nabla_b, nabla_w)`` representing the

        gradient for the cost function C_x.  ``nabla_b`` and

        ``nabla_w`` are layer-by-layer lists of numpy arrays, similar

        to ``self.biases`` and ``self.weights``."""

        nabla_b = [np.zeros(b.shape) for b in self.biases]

        nabla_w = [np.zeros(w.shape) for w in self.weights]

        # feedforward

        activation = x

        activations = [x] # list to store all the activations, layer by layer

        zs = [] # list to store all the z vectors, layer by layer

        for b, w in zip(self.biases, self.weights):

            z = np.dot(w, activation)+b

            zs.append(z)                              # middle variable z before sigmoid, z1,z2

            activation = sigmoid(z)

            activations.append(activation)            # activation output, x, s1,s2

        # backward pass

        delta = self.cost_derivative(activations[-1], y) * \                # C=1/2 *(s2-y).^2, so dc/ds=(s2-y)

            sigmoid_prime(zs[-1])                                            # delta 10*1

        nabla_b[-1] = delta

        nabla_w[-1] = np.dot(delta, activations[-2].transpose())           # s1: 30*1, s1':1*30; delta:10*1, dot:10*30

        # Note that the variable l in the loop below is used a little

        # differently to the notation in Chapter 2 of the book.  Here,

        # l = 1 means the last layer of neurons, l = 2 is the

        # second-last layer, and so on.  It's a renumbering of the

        # scheme in the book, used here to take advantage of the fact

        # that Python can use negative indices in lists.

        for l in xrange(2, self.num_layers):

            z = zs[-l]                                                         

            sp = sigmoid_prime(z)                                           #sp1: dz1, 30*1

            delta = np.dot(self.weights[-l+1].transpose(), delta) * sp       # w[1]: 10*30;  delta update to 30*1 

            nabla_b[-l] = delta

            nabla_w[-l] = np.dot(delta, activations[-l-1].transpose())      # delta 30*1, l=2, s0=x,784*1, ze w[-2]=w[0]=30*784 

        return (nabla_b, nabla_w)
    def cost_derivative(self, output_activations, y):

        """Return the vector of partial derivatives \partial C_x /

        \partial a for the output activations."""

        return (output_activations-y)        
```

　　完整代码请参考[书籍配套代码](https://github.com/mnielsen/neural-networks-and-deep-learning/blob/master/src/network.py)。  





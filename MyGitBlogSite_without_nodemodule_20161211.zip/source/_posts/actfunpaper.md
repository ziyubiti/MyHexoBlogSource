---
title: 神经网络不同激活函数比较--读《Understanding the difficulty of training deep feedforward neural networks》
date: 2016-11-01 19:05:49
tags: DeepLearning
categories: ML
---

　　![various activation functions performance](../../../../imgs/nnactfun/1.png)  
　　这篇论文比较了不同激活函数的中间各隐层输出值分布、梯度值分布、测试准确度等，从上图看出，至少在mnist和cifar10测试集下，看起来tanh和softsign都要好于sigmoid。

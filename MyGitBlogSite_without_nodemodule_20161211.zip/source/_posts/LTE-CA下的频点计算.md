---
title: LTE CA下的频点计算
date: 2015-08-14 17:15:43
tags: [LTE]
categories: [5G]
---
  
目前LTE TDD已部署CA，对于不同带宽的CA，部署时如何计算各个CC的中心频点呢？并且复合后的CA带宽是多少？
  
![Figure 1: CA BW](../../../../imgs/CA_blog/CA1.jpg)  
  

关键公式主要有三个，由此可计算出所有参数。
![Figure 2: CA CC space](../../../../imgs/CA_blog/CA2.jpg)  
![Figure 3: CA nominalGuardBand](../../../../imgs/CA_blog/CA3.jpg)  
![Figure 4: CA F_offset](../../../../imgs/CA_blog/CA4.jpg)  



以连续intra-band 3CC，分别为10M、15M、20M带宽为例，计算参数如下：
![Figure 5: CA para](../../../../imgs/CA_blog/CA6.jpg)  


其频谱形状如下：  
![Figure 6: CA Spectrum](../../../../imgs/CA_blog/CA5.jpg)  

---
title: use Hexo to setup a blog 
date: 2016-07-08 02:52:38
tags: Hexo
categories: ML
---

Hexo is a simply static blog rumtime.

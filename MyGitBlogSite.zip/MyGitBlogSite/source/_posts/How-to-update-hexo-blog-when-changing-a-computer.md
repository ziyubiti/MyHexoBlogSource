---
title: How to update hexo blog when changing a computer?
date: 2016-07-11 23:52:57
tags: Hexo
categories: web
---

 **method 1: github**
    在原电脑将Hexo服务端文件全部提交到github, 在新电脑拉出github仓库，进行正常Hexo操作即可。
 **method 2: copy file**
    首先按照搭建hexo的过程一步步重新在新电脑上操作，之后只要用原电脑的scaffolds, source, themes 和 _config.yml替换新生成的文件就行了；为方便可以将服务端整个文件夹拷贝下来。
